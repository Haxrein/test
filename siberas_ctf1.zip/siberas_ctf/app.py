from flask import Flask, make_response, redirect, render_template ,request, jsonify, url_for
from numpy import equal
import hashlib
import cryptocode
import sqlite3

app = Flask(__name__)


@app.route('/')
def hello():
    id = request.cookies.get('id')
    name = request.cookies.get('name')
    if id:
        decoded = cryptocode.decrypt(id, "redbull_kanatlandirir")
        if decoded == "soru1":
            resp = make_response(redirect('/soru1'))
            return resp
        elif decoded == "soru2":
            resp = make_response(redirect('/soru2'))
            return resp
        elif decoded == "soru3":
            resp = make_response(redirect('/soru3'))
            return resp
        elif decoded == "soru4":
            resp = make_response(redirect('/soru4'))
            return resp
        elif decoded == "soru5":
            resp = make_response(redirect('/soru5'))
            return resp
        elif decoded == "finished":
            #resp = make_response(redirect('/soru2'))
            #return resp
            #return render_template('cer.html')
            data = cryptocode.decrypt(name, "redbull_kanatlandirir")
            return render_template('cer.html', data=data)
        else:
            return render_template('index.html')
    else:
        return render_template('index.html')

@app.route('/soru1', methods=['GET', 'POST'])
def soru1():

    name = request.cookies.get('id')

    if name:
        decoded = cryptocode.decrypt(name, "redbull_kanatlandirir")
        if decoded == "soru1":
            #resp = make_response(redirect('/soru1'))
            #return resp
            return render_template('soru1.html')
        else:
            resp = make_response(redirect('/'))
            return resp
    else:
        return render_template('index.html')
    
    #return render_template('index.html')

@app.route('/soru2', methods=['GET', 'POST'])
def soru2():

    name = request.cookies.get('id')

    if name:
        decoded = cryptocode.decrypt(name, "redbull_kanatlandirir")
        if decoded == "soru2":
            #resp = make_response(redirect('/soru1'))
            #return resp
            return render_template('soru2.html')
        else:
            resp = make_response(redirect('/'))
            return resp
    else:
        return render_template('index.html')
    
    #return render_template('index.html')

@app.route('/soru3', methods=['GET', 'POST'])
def soru3():

    name = request.cookies.get('id')

    if name:
        decoded = cryptocode.decrypt(name, "redbull_kanatlandirir")
        if decoded == "soru3":
            #resp = make_response(redirect('/soru1'))
            #return resp
            return render_template('soru3.html')
        else:
            resp = make_response(redirect('/'))
            return resp
    else:
        return render_template('index.html')
    
    #return render_template('index.html')
@app.route('/soru4', methods=['GET', 'POST'])
def soru4():

    name = request.cookies.get('id')

    if name:
        decoded = cryptocode.decrypt(name, "redbull_kanatlandirir")
        if decoded == "soru4":
            #resp = make_response(redirect('/soru1'))
            #return resp
            return render_template('soru4.html')
        else:
            resp = make_response(redirect('/'))
            return resp
    else:
        return render_template('index.html')
    
@app.route('/soru5', methods=['GET', 'POST'])
def soru5():

    name = request.cookies.get('id')

    if name:
        decoded = cryptocode.decrypt(name, "redbull_kanatlandirir")
        if decoded == "soru5":
            #resp = make_response(redirect('/soru1'))
            #return resp
            return render_template('soru5.html')
        else:
            resp = make_response(redirect('/'))
            return resp
    else:
        return render_template('index.html')
       

@app.route('/control', methods=['POST'])
def control():



    id = request.cookies.get('id')
    if id:
        decoded = cryptocode.decrypt(id, "redbull_kanatlandirir")
        if decoded == "soru1":
            flag = request.form['flag']
            if flag == "siberas{falan_filan}":
                flag_istrue = "true"

                encoded = cryptocode.encrypt("soru2","redbull_kanatlandirir")

                resp = make_response(render_template('correct.html', flag=flag_istrue))

                resp.set_cookie('id', encoded)

                return resp

                #return render_template('soru1.html', flag=flag_istrue)
            else:
                flag_istrue = "false"
                return render_template('soru1.html', flag=flag_istrue)
        elif decoded == "soru2":
            flag = request.form['flag']
            if flag == "siberas{kus_uctu}":
                flag_istrue = "true"

                encoded = cryptocode.encrypt("soru3","redbull_kanatlandirir")

                resp = make_response(render_template('correct.html', flag=flag_istrue))

                resp.set_cookie('id', encoded)

                return resp

                #return render_template('soru1.html', flag=flag_istrue)
            else:
                flag_istrue = "false"
                return render_template('soru2.html', flag=flag_istrue)
                #return render_template('correct.html', flag=flag_istrue)
            #resp = make_response(redirect('/soru1'))
            #return resp
            #return "soru1"
        elif decoded == "soru3":
            flag = request.form['flag']
            if flag == "siberas{malware_4ever}":
                flag_istrue = "true"

                encoded = cryptocode.encrypt("soru4","redbull_kanatlandirir")

                resp = make_response(render_template('correct.html', flag=flag_istrue))

                resp.set_cookie('id', encoded)

                return resp

                #return render_template('soru1.html', flag=flag_istrue)
            else:
                flag_istrue = "false"
                return render_template('soru3.html', flag=flag_istrue)
                #return render_template('correct.html', flag=flag_istrue)
            #resp = make_response(redirect('/soru1'))
            #return resp
            #return "soru1"
        elif decoded == "soru4":
            flag = request.form['flag']
            if flag == "siberas{tak_yerde}":
                flag_istrue = "true"

                encoded = cryptocode.encrypt("soru5","redbull_kanatlandirir")

                resp = make_response(render_template('correct.html', flag=flag_istrue))

                resp.set_cookie('id', encoded)

                return resp

                #return render_template('soru1.html', flag=flag_istrue)
            else:
                flag_istrue = "false"
                return render_template('soru4.html', flag=flag_istrue)

        elif decoded == "soru5":
            
            if request.method == 'POST':

                user = request.form['user']

                password = request.form['password']

                if user == "admin" and password == "admin":
                    flag_istrue = "true"

                    encoded = cryptocode.encrypt("finished","redbull_kanatlandirir")

                    resp = make_response(render_template('correct.html', flag=flag_istrue))

                    resp.set_cookie('id', encoded)

                    return resp
                else:
                    flag_istrue = "false"
                    return render_template('soru5.html', flag=flag_istrue)
        else:
            return redirect('/')
    else:
        return render_template('index.html')
    #return "zort"
    #return render_template('index.html')



@app.route('/register', methods=['POST']) 
def register():

   name = request.form['name']

   email = request.form['email']

   if name == "" or email == "":
       return make_response(redirect('/'))

   conn = sqlite3.connect('database.db')

   with sqlite3.connect("database.db") as con:
    cur = con.cursor()
    cur.execute("INSERT INTO login (name,email) VALUES (?,?)",(name,email) )
    con.commit()

   #result = hashlib.md5(name.encode())

   result = cryptocode.encrypt(name,"redbull_kanatlandirir")

   encoded = cryptocode.encrypt("soru1","redbull_kanatlandirir")

   resp = make_response(redirect('/'))
   #resp.set_cookie('name', str(result.hexdigest()))
   resp.set_cookie('name', result)
   resp.set_cookie('id', encoded)

   return resp

   """
    cookie1 = request.cookies.get('id')
    
    if cookie1 != NULL:
        res = make_response()
        name = request.form['name']
        email = request.form['email']
        res.set_cookie("id", value=name+"_SIBERAS_"+email)
        res.set_cookie("soru", value="1")
        with open('data.txt', 'a+') as f:
            f.write(str(name) + ' ' + str(email) + '\n')
        return redirect('/soru1')
    else:
        return redirect('/soru1')
    """
    #return name + "" + email
    #return jsonify(data)

@app.route('/login', methods=['GET', 'POST']) 
def login():

    if request.method == 'POST':
        user = request.form['user']
        password = request.form['password']

        if user == "siber" and password == "pırasalar":
            result = cryptocode.encrypt("zort","redbull_kanatlandirir")
            resp = make_response(redirect('/show'))
            resp.set_cookie('secret', result)
            return resp
        else:
            return render_template('login.html')
    else:
        return render_template('login.html')

@app.errorhandler(404)
def e404(e):
    # note that we set the 404 status explicitly
    #return "404"
    return redirect('/')

@app.errorhandler(405)
def e405(e):
    # note that we set the 404 status explicitly
    #return "404"
    return redirect('/')   

@app.route('/show')
def deneme():

    secret = request.cookies.get('secret')
    if secret:
        con = sqlite3.connect("database.db")
        con.row_factory = sqlite3.Row
   
        cur = con.cursor()
        cur.execute("select * from login")
   
        a = ""

        rows = cur.fetchall()


        list_accumulator = []
        for item in rows:
            list_accumulator.append({k: item[k] for k in item.keys()})

        return render_template("rows.html", list_accumulator=list_accumulator)
    else:
        return redirect('/')


def dict_from_row(row):
    return dict(zip(row.keys(), row))         
   
@app.route('/clearcookie', methods=['GET', 'POST'])
def clearcookie():

   resp = make_response(redirect('/'))
   resp.delete_cookie('id')
   resp.delete_cookie('name')
   return resp

@app.route('/flag.php')
def flag():

    id = request.cookies.get('id')
    if id:
        return render_template('soru4_flag.html')
    else:
        return redirect("/")
